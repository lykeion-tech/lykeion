### Task 1: Personal Aristotle persistence and bootstrap
Own server migration, SQL/generated queries, handler bootstrap/agents and backend tests only. No frontend changes.
- Add built-in agent identity, ordered starters, conversation classification/title metadata and configuration snapshot storage needed by Task 2.
- Make uniqueness permit one Aristotle per workspace/member while retaining ordinary live-agent name uniqueness. Keep existing ordinary Aristotle intact.
- Add POST /api/coresearch/bootstrap returning agent, welcome conversation and enough project/chat IDs to navigate. Invoke later from frontend at lab startup. Transactionally ensure agent and private welcome backing project/chat once; concurrency must be safe; no CLI/machine requirement.
- Add GET /api/coresearch/conversations to list current member's conversations with id/project_id/chat_id/title/preview/is_welcome and timestamps, omitting private backing projects from ordinary project list.
- Extend agent GET/PATCH fields for built_in_key and conversation_starters; prohibit public builtin creation/identity mutation, builtin archive or visibility change. Seed editable profile and instructions; enforce existing edit authorization.
- Extend active agent API validation for ordered label/prompt pairs (max 12, label 120 characters, prompt 16 KiB, no empty fields/NUL/invalid UTF-8; empty array means defaults).
- Use tests first: repeated/concurrent bootstrap, two members, cross-workspace, existing-name collision, no runtime, no duplicates/settings overwrite, ordinary name uniqueness, privacy and archive restrictions, starter roundtrip/validation.
- Keep schema/query changes generated using current repo tooling and document interfaces for Task 2/3 in report.

