### Task 2: Atomic conversations and snapshotted execution
Own server Coresearch queue/handlers/runtime integration/SQL and tests; no frontend changes.
- Add POST /api/coresearch/conversations accepting body and client-generated request_id UUID. Atomically create private backing project/chat, capture caller's Aristotle config, accept/enqueue first turn and return conversation. Replays return same accepted result; reject request-id reuse with changed payload.
- Add POST /api/coresearch/conversations/{id}/turns for welcome/normal turns with body and request_id. Welcome snapshots on first accepted turn; all sends idempotent. Existing project chat turn APIs remain compatible.
- Validate caller ownership/workspace, available authorized own machine matching snapshotted harness before acceptance; no partial creation on failure. Preserve current sandbox/tool authorization, cancellation and stream paths by returning existing chat/project/run IDs.
- Apply frozen instructions to actual prompt, propagate configured model through enqueue/claim/daemon/provider invocation for Aristotle only; keep ordinary Coresearch provider-default behavior. Fail closed on untrusted client config.
- Concurrency tests for first turn/config snapshot and idempotent retry, unavailable machine retry, current setting changes versus existing snapshots, both Claude/Codex model argument propagation, cross-member/workspace and normal project regressions.
- Ensure welcome static content is not represented as a fake generated response; UI handles built-in intro.

