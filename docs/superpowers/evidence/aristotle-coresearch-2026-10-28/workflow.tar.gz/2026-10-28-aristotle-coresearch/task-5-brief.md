### Task 5: Keep Coresearch independent from Projects (user clarification)
Own ConversationRail.vue and one focused unit regression only; no backend changes.
- Remove Projects header, folder/manage links, project listing and useCoresearchProjects query from conversation rail.
- Accessible rail name becomes Conversations. Keep conversation history, +, Settings and FAB behavior.
- Main navigation Projects entry and actual Projects feature remain unchanged; existing direct legacy Coresearch URLs remain supported.
- Prove rail has no Projects links/content and does not fetch ordinary Coresearch project list; prove conversation links/+ remain. Task4 acceptance updates corresponding assertions and verifies main navigation Projects still goes to /projects.
