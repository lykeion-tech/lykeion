### Task 4: End-to-end acceptance and final integration
Own focused e2e tests and task-owned evidence; fixes assigned back to relevant implementers.
- Add browser tests for bootstrap first welcome, + unsaved draft, starter send/retry, starter settings save/reflection, reload/last chat, FAB switching, existing project access, global New, no-machine blocker, light/dark/narrow layout.
- Run typecheck, lint/format exact changed files, frontend suites, focused Playwright, affected backend packages sequentially; widen only for changes/failures. Real browser verify actual Local Lab at 1431/1430, update backend preview only after protecting lab state and applying migration.
- Whole-branch spec/security/quality review, fix real findings, retain evidence and report honest live/runtime limitations. Leave preview accessible. No merge or push.
