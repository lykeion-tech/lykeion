import json, os, pathlib, signal, socket, subprocess, time
root = pathlib.Path('/tmp/lykeion-local-preview-20261028-7871bf9b')
state_path = pathlib.Path('/tmp/lykeion-local-preview-current.json')
state = json.loads(state_path.read_text())
secrets = json.loads((root/'secrets/values.json').read_text())
# Caller builds the binary sequentially before running this script.
binary = root/'bin/lykeion-server-aristotle'
assert binary.is_file()
pid = state['server_pid']
command = subprocess.check_output(['ps','-p',str(pid),'-o','command='], text=True).strip()
assert str(root/'bin/') in command and 'lykeion-server' in command, 'Unexpected preview process'
# Snapshot the preview database before the additive migration. Never print credentials.
with (root/'secrets/before-aristotle.sql').open('wb') as backup:
    subprocess.run(['docker','exec',state['pg_container'],'pg_dump','-U','owner','--clean','--if-exists','lykeion_preview'], stdout=backup, check=True)
os.chmod(root/'secrets/before-aristotle.sql', 0o600)
os.kill(pid, signal.SIGTERM)
for _ in range(100):
    try: os.kill(pid, 0)
    except ProcessLookupError: break
    time.sleep(.1)
else: raise RuntimeError('Preview process did not exit')
env = os.environ.copy()
env.update(DATABASE_URL=f"postgres://lykeion_app:{secrets['app_password']}@127.0.0.1:{state['pg_port']}/lykeion_preview?sslmode=disable", MIGRATE_DATABASE_URL=f"postgres://owner:{secrets['owner_password']}@127.0.0.1:{state['pg_port']}/lykeion_preview?sslmode=disable", REDIS_URL=f"redis://127.0.0.1:{state['redis_port']}", JWT_SECRET=secrets['jwt'], STORAGE='local:'+str(root/'blobs'), COOKIE_SECURE='false', PUBLIC_URL=f"http://127.0.0.1:{state['ui_port']}", LISTEN_ADDR=f"127.0.0.1:{state['api_port']}")
log = (root/'logs/server-aristotle.private.log').open('ab')
proc = subprocess.Popen([str(binary)], env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
for _ in range(150):
    if proc.poll() is not None: raise RuntimeError('Preview failed; inspect private log without exposing secrets')
    try:
        with socket.create_connection(('127.0.0.1', state['api_port']), timeout=.2): break
    except OSError: time.sleep(.1)
else: raise RuntimeError('Preview readiness timed out')
state.update(server_pid=proc.pid, backend_checkout=str(pathlib.Path.cwd()), backend_branch='codex/browser-comments')
state_path.write_text(json.dumps(state, indent=2)+'\n')
print('Preview API refreshed; previous lab data retained; pid', proc.pid)
